package com.shiku.imserver.common;

public interface Status {
   int getCode();

   String getMsg();
}
