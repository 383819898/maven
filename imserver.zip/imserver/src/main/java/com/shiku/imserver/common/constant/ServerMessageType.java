package com.shiku.imserver.common.constant;

public interface ServerMessageType {
   short refreshConfig = 1;
   short refreshKeyWords = 2;
}
