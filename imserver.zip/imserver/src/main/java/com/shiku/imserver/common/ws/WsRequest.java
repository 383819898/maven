package com.shiku.imserver.common.ws;

public class WsRequest extends WsPacket {
   private static final long serialVersionUID = -3361865570708714596L;
}
