package com.shiku.imserver.common;

public interface IService {
   boolean initialize();

   boolean startupAfter();
}
