package com.shiku.imserver.common;

public interface ISessionContext {
}
