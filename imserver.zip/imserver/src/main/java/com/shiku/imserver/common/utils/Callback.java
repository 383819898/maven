package com.shiku.imserver.common.utils;

public interface Callback {
   void execute(Object var1);
}
