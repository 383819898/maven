package com.shiku.imserver.common.message;

public class SuccessMessage extends AbstractMessage {
   private static final long serialVersionUID = 1L;
}
