package com.shiku.imserver.common.message;

import java.io.Serializable;

public interface IMessage extends Serializable, Cloneable {
}
