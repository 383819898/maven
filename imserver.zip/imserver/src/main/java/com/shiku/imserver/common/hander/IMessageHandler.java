package com.shiku.imserver.common.hander;

import java.lang.reflect.Method;

public interface IMessageHandler {
   Method getMessageHandler(short var1);
}
