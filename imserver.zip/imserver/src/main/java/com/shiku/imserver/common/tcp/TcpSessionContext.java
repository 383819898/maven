package com.shiku.imserver.common.tcp;

import com.shiku.imserver.common.ImSessionContext;

public class TcpSessionContext extends ImSessionContext {
}
