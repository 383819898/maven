package com.shiku.imserver.common.message;

public class PingMessage extends AbstractMessage {
}
